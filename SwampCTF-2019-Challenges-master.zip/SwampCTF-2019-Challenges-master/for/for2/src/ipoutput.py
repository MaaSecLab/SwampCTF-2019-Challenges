hexN = '0x41ba0320'
print(hexN)
hexP = hexN[2:]
print (hexP[0:2])
print (hexP[2:4])
print (hexP[4:6])
print (hexP[6:8])

print(hexP)
print("{}.{}.{}.{}".format(hexP[0:2],hexP[2:4],hexP[4:6],hexP[6:8]))