Flavor:
"Two of our squad leaders got beamed up before they could finish their transmission, but they left a clue behind as to where they were taken."

Solution:
Change levels in photoshop and look the top image to get the flag. Still need to extract flag and enter into CTFd
