# [SwampCTF 2019 Pwn] Wetware / Wetware 2

## Flavor Text

> *Molly:* Johnny's Datapak has been corrupted.  We have the isomorph passphrase to decode the archive, but it looks like the decompression Neurosoft got tripped up by Johhny's quack neurodoc.  Can you splice in and just make it work?
> *J-Bone:* Sure, you mentioned a key?
> 
> *Molly:* Yeah, it's "mnemonic"
> 
> *J-Bone:* Okay, n-e-m-o...
> 
> *Molly:* It starts with an "M"
> 
> *J-Bone:* What? Friggin english... Okay, well, this is pretty cryptic. I think this is gonna be beyond my capabilities.
> 
> *J-Bone turns to you*: Hey, I hear you got some skills, wanna give it a try?
> 
> `nc chal1.swampctf.com 1337`

* Flag: `flag{51mpl3_C0d3_f0r_4_S1mpl3_j0b}`
* Expected difficulty: unknown

**For wetware 2, see src2 directory**

## Description
**No description**


## Challenge Solution
**No solution**
