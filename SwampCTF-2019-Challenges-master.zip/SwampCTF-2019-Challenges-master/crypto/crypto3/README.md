# [SwampCTF 2019 Cryptography] Communique

## Flavor Text

> We've retrieved the message from the courier! The damn thing was stuck in this pit! Man...if only we'd had another day to get the supplies to them they might have made it through the hot zone. In any case, the document is concise and short; hand it in when you've decoded it.

* Flag: `flag{pitmanwascool}`
* Expected difficulty: medium

## Description
**No description**

## Challenge Solution
**see Writeup.jpg**
