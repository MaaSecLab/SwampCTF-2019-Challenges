key1 = "flag{w0w_wh4t_l4"
key2 = "zy_k3yz_much_w34"
key3 = "k_crypt0_f41ls!}"
